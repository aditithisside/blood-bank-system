<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\BloodSampleController;
use App\Http\Controllers\RequestController;
use App\Http\Controllers\ProfileController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    $user = Auth::user();

    if ($user->role === 'hospital') {
        return view('hospital-dashboard');
    } elseif ($user->role === 'receiver') {
        return view('receiver-dashboard');
    } else {
        abort(403, 'Invalid role');
    }
})->middleware(['auth'])->name('dashboard');

// Profile Routes
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Blood Sample Routes
Route::get('/blood-list', [BloodSampleController::class, 'index'])->middleware(['auth'])->name('blood.list');

Route::middleware(['auth'])->group(function () {
    Route::get('/add-blood', [BloodSampleController::class, 'create'])->name('blood.create');
    Route::post('/add-blood', [BloodSampleController::class, 'store'])->name('blood.store');
});

// Blood Request Routes
Route::post('/request-blood', [RequestController::class, 'store'])->middleware(['auth'])->name('request.blood');

// Hospital: View Received Requests
Route::get('/hospital/requests', [RequestController::class, 'hospitalRequests'])
    ->middleware(['auth'])
    ->name('hospital.requests');

// Auth Scaffolding
require __DIR__.'/auth.php';

