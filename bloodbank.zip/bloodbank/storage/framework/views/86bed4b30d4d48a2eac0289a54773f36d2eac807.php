<!DOCTYPE html>
<html>
<head>
    <title>Blood Bank App</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.7/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">

    <div class="text-center">
        <h1 class="text-4xl font-bold mb-6">Welcome to Blood Bank</h1>

        <?php if(Route::has('login')): ?>
            <div class="space-x-4">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="text-blue-600 underline">Dashboard</a>

                    <!-- ✅ Proper Logout Form -->
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-red-600 underline">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-blue-600 underline">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="text-blue-600 underline">Register</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\bloodbank\resources\views/welcome.blade.php ENDPATH**/ ?>