

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto mt-10">
        <h2 class="text-2xl font-bold mb-4">Available Blood Samples</h2>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <ul class="space-y-4">
            <?php $__currentLoopData = $samples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="p-4 bg-white rounded shadow">
                    <p><strong>Type:</strong> <?php echo e($sample->blood_type); ?></p>
                    <p><strong>Quantity:</strong> <?php echo e($sample->quantity); ?></p>
                    <p><strong>Hospital:</strong> <?php echo e($sample->user->name); ?></p>

                    <?php if(Auth::user()->role === 'receiver'): ?>
                        <form action="<?php echo e(route('request.blood')); ?>" method="POST" class="mt-2">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="blood_sample_id" value="<?php echo e($sample->id); ?>">
                            <button type="submit"
                                class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
                                Request
                            </button>
                        </form>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodbank\resources\views/blood-list.blade.php ENDPATH**/ ?>