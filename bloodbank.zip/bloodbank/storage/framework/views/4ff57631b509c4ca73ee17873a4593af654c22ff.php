

<?php $__env->startSection('content'); ?>
    <h2 class="text-xl font-bold mb-4">Received Blood Requests</h2>

    <?php if($requests->count()): ?>
        <ul>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="mb-2 p-2 border">
                    <strong>Requested by:</strong> <?php echo e($req->user->name); ?> <br>
                    <strong>Blood Type:</strong> <?php echo e($req->bloodSample->blood_type); ?> <br>
                    <strong>Quantity:</strong> <?php echo e($req->bloodSample->quantity); ?> <br>
                    <strong>Status:</strong> <?php echo e($req->status); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <p>No blood requests yet.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodbank\resources\views/hospital/requests.blade.php ENDPATH**/ ?>