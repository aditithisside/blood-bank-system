<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <?php if(session('status') === 'profile-updated'): ?>
                    <div class="mb-4 font-medium text-sm text-green-600">
                        <?php echo e(__('Profile updated successfully.')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <!-- Name -->
                    <div class="mb-4">
                        <label class="block text-gray-700">Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded p-2">
                    </div>

                    <!-- Email -->
                    <div class="mb-4">
                        <label class="block text-gray-700">Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded p-2">
                    </div>

                    <!-- State -->
                    <div class="mb-4">
                        <label class="block text-gray-700">State</label>
                        <input type="text" name="state" value="<?php echo e(old('state', $user->state)); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded p-2">
                    </div>

                    <!-- Address -->
                    <div class="mb-4">
                        <label class="block text-gray-700">Address</label>
                        <input type="text" name="address" value="<?php echo e(old('address', $user->address)); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded p-2">
                    </div>

                    <!-- Submit -->
                    <div>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bloodbank\resources\views/profile/edit.blade.php ENDPATH**/ ?>