


<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Hospital Dashboard</h1>

    <a href="<?php echo e(route('blood.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        ➕ Add Blood Sample
    </a>

    <a href="<?php echo e(route('hospital.requests')); ?>" class="ml-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        📄 View Blood Requests
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodbank\resources\views/hospital-dashboard.blade.php ENDPATH**/ ?>