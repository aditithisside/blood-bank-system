

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Receiver Dashboard</h1>

    <a href="<?php echo e(route('blood.list')); ?>" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
        🩸 View Available Blood Samples
    </a>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodbank\resources\views/receiver-dashboard.blade.php ENDPATH**/ ?>