@extends('layouts.app')

@section('content')
    <h2 class="text-xl font-bold mb-4">Received Blood Requests</h2>

    @if($requests->count())
        <ul>
            @foreach($requests as $req)
                <li class="mb-2 p-2 border">
                    <strong>Requested by:</strong> {{ $req->user->name }} <br>
                    <strong>Blood Type:</strong> {{ $req->bloodSample->blood_type }} <br>
                    <strong>Quantity:</strong> {{ $req->bloodSample->quantity }} <br>
                    <strong>Status:</strong> {{ $req->status }}
                </li>
            @endforeach
        </ul>
    @else
        <p>No blood requests yet.</p>
    @endif
@endsection
